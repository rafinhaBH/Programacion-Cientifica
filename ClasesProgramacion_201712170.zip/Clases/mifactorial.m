function fact=mifactorial(num)
fact=1;
for i=2:num
    fact=fact*(i);
end