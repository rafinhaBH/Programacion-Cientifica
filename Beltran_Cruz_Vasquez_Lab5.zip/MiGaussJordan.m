function [x]= MiGaussJordan(A, B)

N = size(A, 1);
M = size(B, 2);
% Aau = [A B];
Aau = zeros(N, (N + M));
for i=1:N
    for j=1:(N+M)
        if j <= N
            Aau(i, j) = A(i, j);
        else
            Aau(i, j) = B(i, (j - N));
        end
    end
end

for h=1:N
    
    if Aau(h,h) ~= 0
        Aau(h, :) = Aau(h, :)/Aau(h, h);
    
        for g=1:N
            if g ~= h
                Aau(g,:) = Aau(g,:) - (Aau(h, :)*Aau(g,h));
            end
        end
    end
end

x = zeros(N, M);
for s=1:M
    x(:,s) = Aau(:, (N + s));
end
end



